package za.co.mecer.exceptions;

/**
 *
 * @author Dimakatso Sebatane
 */
public class CardException extends Exception {

    public CardException(String msg) {
        super(msg);
    }
}
