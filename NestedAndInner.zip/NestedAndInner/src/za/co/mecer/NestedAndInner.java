package za.co.mecer;

import za.co.mecer.outerclass.OuterClass;

/**
 *
 * @author Dimakatso Sebatane
 */
public class NestedAndInner {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new NestedAndInner().run();
    }

    private void run() {
        OuterClass outerClass = new OuterClass(31);
        OuterClass.InnerClass innerClass = outerClass.new InnerClass(254);

        System.out.println(outerClass.toString());
        System.out.println(innerClass.toString());

        outerClass.setInnerClassRef();
        System.out.println("Value: " + outerClass.getInnerClassRef().getInnerValue());
    }
}
