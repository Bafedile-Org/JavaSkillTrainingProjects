package za.co.mecer.game.exceptions;

/**
 *
 * @author Dimakatso Sebatane
 */
public class GameException extends Exception {

    public GameException(String msg) {
        super(msg);
    }
}
