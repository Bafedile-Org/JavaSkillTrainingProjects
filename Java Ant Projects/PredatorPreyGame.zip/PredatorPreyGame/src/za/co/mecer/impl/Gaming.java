package za.co.mecer.impl;

/**
 *
 * @author Dimakatso Sebatane
 */
public interface Gaming {

    int ANTS_NUM = 5;
    int BUGS_NUM = 3;
    int GRID_LENGTH = 3;
}
