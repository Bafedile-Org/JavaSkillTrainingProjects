package za.co.mecer;

import za.co.mecer.doubles.DoubleClass;
import za.co.mecer.generic.GenericClass;
import za.co.mecer.integer.IntegerClass;
import za.co.mecer.string.StringClass;

/**
 *
 * @author Dimakatso Sebatane
 */
public class GenericsTest {

    public static void main(String[] args) {
        new GenericsTest().run();
    }

    private void run() {
        new IntegerClass(3).printValue();
        new DoubleClass(5.2).printValue();
        new StringClass("Hello There").printValue();

        System.out.println("/-----------------------------------------\n");

        coolMethod(new GenericClass<Integer>(2));
        coolMethod(new GenericClass<Double>(2.5));
        coolMethod(new GenericClass<String>("Hi"));
        coolMethod(new GenericClass<Long>(90L));
        coolMethod(new GenericClass<Boolean>(true));

    }

    private void coolMethod(GenericClass gen) {
        gen.printValue();
    }

}
