package za.co.mecer.interfaces;

/**
 *
 * @author Dimakatso Sebatane
 */
public interface PlayerInterface {

    String getName();
}
