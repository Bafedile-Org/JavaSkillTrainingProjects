package za.co.mecer.cards.suits;

/**
 *
 * @author Dimakatso Sebatane
 */
public enum Suits {
    SPADE, HEARTS, DIAMONDS, CLUBS
}
